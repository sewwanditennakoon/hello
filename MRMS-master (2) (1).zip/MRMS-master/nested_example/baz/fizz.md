# Fizz

How to find a fizz in the wild.

Link to [Foobar](baz/foobar.md) at the same level as this `fizz.md` file, using `baz/foobar.md` (relative to docs directory).

Link to [Bar](bar.md) using `bar.md`, as this is implied to be relative to docs. You could use `../bar.md` as that is valid, but the text in the URL bar will look weird.
