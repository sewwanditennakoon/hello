# Foo

## H2 for Foo

### H3 for Foo

Link to [Bar](bar.md) at the same level and to [Fizz](baz/fizz.md) one level down.
