# Nested example

The files in this directory demonstrate what file linking and nested docs structure look like when using a custom sidebar such as [_sidebar.md](_sidebar.md).

This [nested_example](/nested_example) directory was tested using a _Docsify_ server, but was reduced to just the content and sidebar file to serve as a lean example that does not run.
