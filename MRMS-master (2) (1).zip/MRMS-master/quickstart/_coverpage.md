<!-- TODO: Set project title and the description. For Github release, replace USERNAME and REPO-NAME, or delete the line. -->
# My Project Name

[![GitHub release](https://img.shields.io/github/tag/USERNAME/REPO-NAME.svg)](https://GitHub.com/USERNAME/REPO-NAME/tags/)

> My project description

<!-- TODO: List zero or more short sentences about the project's benefits/features. -->

- Feature
- Feature
- Feature

[GitHub](https://github.com/USERNAME/REPO-NAME/) <!-- TODO: Use your repo's path.-->
[Getting Started](#my-project-name) <!-- TODO: Use ID of homepage heading i.e. based on H1 of README.md -->
