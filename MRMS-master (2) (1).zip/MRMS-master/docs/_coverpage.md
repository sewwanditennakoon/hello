![icon](_media/Ceylon-Electricity-Board.png)

# MRMS USER MANUAL

[GitHub](https://github.com/michaelcurrin/docsify-template/)
[Getting Started](#user-login)
